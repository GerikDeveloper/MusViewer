package org.example;

import java.io.File;
import java.sql.*;

import static org.example.Server.log;

public class DBExecutor {

    public static boolean loadDB() {
        log("Loading exhibits db...");
        if (new File("data/exhibits.db").exists()) {
            try {
                Connection exhibitsDB = DriverManager.getConnection("jdbc:sqlite:data/exhibits.db");
                Statement LoadingStatement = exhibitsDB.createStatement();
                LoadingStatement.execute("CREATE TABLE IF NOT EXISTS exhibits(" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "ICN TEXT NOT NULL UNIQUE, " +
                        "xPos INTEGER NOT NULL, " +
                        "yPos INTEGER NOT NULL, " +
                        "visitors INTEGER NOT NULL, " +
                        "mark INTEGER NOT NULL, " +
                        "time INTEGER NOT NULL)");
                LoadingStatement.close();
                log("DB has been loaded");
                return true;
            } catch (Exception unkExc) {
                log("Unknown file or sql error");
            }
        }
        return false;
    }

    public static boolean createDB() {
        log("Creating database...");
        try {
            if (new File("data").exists()) {
                log("DBDirectory was found");
            } else {
                log("DBDirectory was not found, \nCreating DBDirectory");
                if (new File("data").mkdirs()) {
                    log("DBDirectory was made");
                } else {
                    log("Failed to create DBDirectory, please restart");
                    return false;
                }
            }
            if (new File("data/exhibits.db").exists()) {
                log("DBFile was found");
            } else {
                log("DBFile was not found, \nCreating DBFile");
                if (new File("data/exhibits.db").createNewFile()) {
                    log("DBFile was made");
                } else {
                    log("Failed to create DBFile, please restart");
                    return false;
                }
            }
            Connection exhibitsDB = DriverManager.getConnection("jdbc:sqlite:data/exhibits.db");
            Statement CreatingStatement = exhibitsDB.createStatement();
            CreatingStatement.execute("CREATE TABLE IF NOT EXISTS exhibits(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "ICN TEXT NOT NULL UNIQUE, " +
                    "xPos INTEGER NOT NULL, " +
                    "yPos INTEGER NOT NULL, " +
                    "visitors INTEGER NOT NULL, " +
                    "mark INTEGER NOT NULL, " +
                    "time INTEGER NOT NULL)");
            CreatingStatement.close();
            log("DB has been created");
            return true;
        } catch (Exception unkExc) {
            log("Unknown file or sqlite error");
            return false;
        }
    }

    public static boolean createExhibit(String icn, short xPos, short yPos, int visitors, byte mark, int time) {
        Connection dbConnection = null;
        PreparedStatement addingStatement = null;
        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:data/exhibits.db");
            addingStatement = dbConnection.prepareStatement("INSERT INTO exhibits (" +
                    "ICN, " +
                    "xPos, " +
                    "yPos, " +
                    "visitors, " +
                    "mark, " +
                    "time) " +
                    "VALUES (?, ?, ?, ?, ?, ?)");
            addingStatement.setString(1, icn);
            addingStatement.setInt(2, xPos);
            addingStatement.setInt(3, yPos);
            addingStatement.setInt(4, visitors);
            addingStatement.setInt(5, mark);
            addingStatement.setInt(6, time);
            int updated = addingStatement.executeUpdate();
            if (updated == 0) throw new Exception();
            addingStatement.close();
            dbConnection.close();
        } catch (Exception unExc) {
            try {
                if (addingStatement != null) addingStatement.close();
                if (dbConnection != null) dbConnection.close();
            } catch (Exception immediatelyClosingException) {
                return false;
            }
            return false;
        }
        return true;
    }

    public static String getStringParam(int id, String column) {
        Connection dbConnection = null;
        PreparedStatement gettingStatement = null;
        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:data/exhibits.db");
            gettingStatement = dbConnection.prepareStatement("SELECT * FROM exhibits WHERE id = ?");
            gettingStatement.setInt(1, id);
            ResultSet statementResult = gettingStatement.executeQuery();
            String result = null;
            if (statementResult.next()) {
                result = statementResult.getString(column);
            } else {
                statementResult.close();
                throw new Exception();
            }
            statementResult.close();
            gettingStatement.close();
            dbConnection.close();
            return result;
        } catch (Exception dbException) {
            try {
                if (gettingStatement != null) gettingStatement.close();
                if (dbConnection != null) dbConnection.close();
            } catch (Exception immediatelyClosingException) {
                return null;
            }
            return null;
        }
    }

    public static int[] getIntParam(int id, String column) {
        Connection dbConnection = null;
        PreparedStatement gettingStatement = null;
        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:data/exhibits.db");
            gettingStatement = dbConnection.prepareStatement("SELECT * FROM exhibits WHERE id = ?");
            gettingStatement.setInt(1, id);
            ResultSet statementResult = gettingStatement.executeQuery();
            int[] result = null;
            if (statementResult.next()) {
                result = new int[] {statementResult.getInt(column)};
            } else {
                statementResult.close();
                throw new Exception();
            }
            statementResult.close();
            gettingStatement.close();
            dbConnection.close();
            return result;
        } catch (Exception dbException) {
            try {
                if (gettingStatement != null) gettingStatement.close();
                if (dbConnection != null) dbConnection.close();
            } catch (Exception immediatelyClosingException) {
                return null;
            }
            return null;
        }
    }

    public static String[] getAllStringParam(int id, String column) {
        Connection dbConnection = null;
        Statement gettingStatement = null;
        Statement countingStatement = null;
        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:data/exhibits.db");
            countingStatement = dbConnection.createStatement();
            ResultSet cntRes = countingStatement.executeQuery("SELECT COUNT(" + column + ")");
            int cnt = 0;
            /**XXX Replace counter with while & List **/
            if (cntRes.next()) {
                cnt = cntRes.getInt(1);
                cntRes.close();
                countingStatement.close();
            } else {
                cntRes.close();
                throw new Exception();
            }
            gettingStatement = dbConnection.createStatement();

            ResultSet statementResult = gettingStatement.executeQuery("SELECT * FROM exhibits");
            String[] result = null;
            if (statementResult.next()) {
                result = new String[cnt];
                int pos = 0;
                result[pos] = statementResult.getString(column);
                while(statementResult.next()) {
                    pos++;
                    result[pos] = statementResult.getString(column);
                }
            } else {
                statementResult.close();
                throw new Exception();
            }
            statementResult.close();
            gettingStatement.close();
            dbConnection.close();
            return result;
        } catch (Exception dbException) {
            try {
                if (countingStatement != null) countingStatement.close();
                if (gettingStatement != null) gettingStatement.close();
                if (dbConnection != null) dbConnection.close();
            } catch (Exception immediatelyClosingException) {
                return null;
            }
            return null;
        }
    }

    public static int[] getAllIntParam(String column) {
        Connection dbConnection = null;
        Statement gettingStatement = null;
        Statement countingStatement = null;
        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:data/exhibits.db");
            countingStatement = dbConnection.createStatement();
            ResultSet cntRes = countingStatement.executeQuery("SELECT COUNT(" + column + ")");
            int cnt = 0;
            /**XXX Replace counter with while & List **/
            if (cntRes.next()) {
                cnt = cntRes.getInt(1);
                cntRes.close();
                countingStatement.close();
            } else {
                cntRes.close();
                throw new Exception();
            }
            gettingStatement = dbConnection.createStatement();
            ResultSet statementResult = gettingStatement.executeQuery("SELECT * FROM exhibits");
            int[] result = null;
            if (statementResult.next()) {
                result = new int[cnt];
                int pos = 0;
                result[pos] = statementResult.getInt(column);
                while(statementResult.next()) {
                    pos++;
                    result[pos] = statementResult.getInt(column);
                }
            } else {
                statementResult.close();
                throw new Exception();
            }
            statementResult.close();
            gettingStatement.close();
            dbConnection.close();
            return result;
        } catch (Exception dbException) {
            try {
                if (countingStatement != null) countingStatement.close();
                if (gettingStatement != null) gettingStatement.close();
                if (dbConnection != null) dbConnection.close();
            } catch (Exception immediatelyClosingException) {
                return null;
            }
            return null;
        }
    }

    public static boolean setStringParam(int id, String column, String data) {
        Connection dbConnection = null;
        PreparedStatement settingStatement = null;
        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:data/exhibits.db");
            settingStatement = dbConnection.prepareStatement("UPDATE exhibits SET " +
                    column +
                    " = ?, " +
                    "WHERE id = ?");
            settingStatement.setString(1, data);
            settingStatement.setInt(2, id);
            int updated = settingStatement.executeUpdate();
            if (updated == 0) throw new Exception();
            settingStatement.close();
            dbConnection.close();
        } catch (Exception dbException) {
            try {
                if (settingStatement != null) settingStatement.close();
                if (dbConnection != null) dbConnection.close();
            } catch (Exception immediatelyClosingException) {
                return false;
            }
            return false;
        }
        return true;
    }

    public static boolean setIntParam(int id, String column, int data) {
        Connection dbConnection = null;
        PreparedStatement settingStatement = null;
        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:data/exhibits.db");
            settingStatement = dbConnection.prepareStatement("UPDATE exhibits SET " +
                    column +
                    " = ?, " +
                    "WHERE id = ?");
            settingStatement.setInt(1, data);
            settingStatement.setInt(2, id);
            int updated = settingStatement.executeUpdate();
            if (updated == 0) throw new Exception();
            settingStatement.close();
            dbConnection.close();
        } catch (Exception dbException) {
            try {
                if (settingStatement != null) settingStatement.close();
                if (dbConnection != null) dbConnection.close();
            } catch (Exception immediatelyClosingException) {
                return false;
            }
            return false;
        }
        return true;
    }

    public static String getICN(int id) {
        return getStringParam(id, "ICN");
    }

    public static boolean setICN(int id, String icn) {
        return setStringParam(id, "ICN", icn);
    }

    public static int[] getXPos(int id) {
        return getIntParam(id, "xPos");
    }

    public static boolean setXPos(int id, int xPos) {
        return setIntParam(id, "xPos", xPos);
    }

    public static int[] getYPos(int id) {
        return getIntParam(id, "yPos");
    }

    public static boolean setYPos(int id, int yPos) {
        return setIntParam(id, "yPos", yPos);
    }

    public static int[] getVisitors(int id) {
        return getIntParam(id, "visitors");
    }

    public static boolean setVisitors(int id, int visitors) {
        return setIntParam(id, "visitors", visitors);
    }

    public static int[] getMark(int id) {
        return getIntParam(id, "mark");
    }

    public static boolean setMark(int id, int mark) {
        return setIntParam(id, "mark", mark);
    }

    public static int[] getTime(int id) {
        return getIntParam(id, "time");
    }

    public static boolean setTime(int id, int time) {
        return setIntParam(id, "time", time);
    }

    public static int[] getAllIds() {
        return getAllIntParam("id");
    }
}
