package org.example;

import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Server {
    public static ServerSocket ssock;
    public static DateFormat dateform;

    public static final String login = "admin";
    public static final String password = "admin";

    public static boolean isWorking() {
        return true;
    }

    public static void log(String data) {
        System.out.println(dateform.format(new Date()) + ": " + data);
    }

    public static void start() {
        dateform = new SimpleDateFormat("yyyy-mm-dd'T'hh:mm:ss");
        try {
            if (!DBExecutor.loadDB()) {
                if (!DBExecutor.createDB()) {
                    throw new Exception();
                }
            }
        } catch (Exception unkExc) {
            log("Failed to load/create db");
            return;
        }
        try {
            log("Opening server socket");
            ssock = new ServerSocket();
        } catch (Exception unkExc) {
            log("Failed to open server socket, please restart");
            return;
        }
        log("Binding server");
        try {
            ssock.bind(new InetSocketAddress(13039));
            log("Server bound successfully");
        } catch (Exception unkExc) {
            log("Failed to bind server, please restart");
            return;
        }
        while(isWorking()) {
            try {
                Socket tmpSock = ssock.accept();
                if (tmpSock != null) {
                    log("New devise connecting");
                    try {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                new Devise(tmpSock);
                            }
                        }).start();
                    } catch (Exception unkExc) {
                        log("Failed to start thread");
                    }
                }
            } catch (Exception unkExc) {}
        }
    }
}
