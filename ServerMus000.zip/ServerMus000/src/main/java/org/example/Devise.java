package org.example;

import java.net.Socket;

import static org.example.Server.log;

public class Devise {

    public static final int timeout = 30;
    private Socket socket;
    private APIStream stream;
    private short type = 0x0000;

    public Devise(Socket sock) {
        socket = sock;
        start();
    }

    private boolean handshake() {
        byte[] hshCode = stream.readShort();
        if (hshCode != null) {
            short code = ByteOperations.getShort(hshCode);
            if (code == Codes.Camera.HANDSHAKE_CODE) {
                if (stream.writeByte(Codes.Camera.OK)) {
                    type = code;
                    return true;
                } else {
                    return false;
                }
            } else if (code == Codes.Host.HANDSHAKE_CODE) {
                if (stream.writeByte(Codes.Host.OK)) {
                    type = code;
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private void start() {
        try {
            stream = new APIStream(socket.getInputStream(), socket.getOutputStream(), timeout);
        } catch (Exception unkExc) {
            log("Failed to open devise stream");
            return;
        }
        if (handshake()) {
            log("Devise successfully checked");
        } else {
            log("Failed to complete handshake");
            stream.close();
            return;
        }
        if (type == Codes.Camera.HANDSHAKE_CODE) {
            camera_oper();
            stream.close();
        } else if (type == Codes.Host.HANDSHAKE_CODE) {
            host_oper();
            stream.close();
        } else {
            log("Unknown code, devise will disconnect");
            stream.close();
            return;
        }
    }

    private void camera_oper() {
        log("1");
    }

    private void host_disconnect() {
        stream.writeByte(Codes.Host.DISC);
    }

    private boolean host_ping() {
        return stream.writeByte(Codes.Host.OK);
    }

    private boolean host_gaeid() {
        int[] ids = DBExecutor.getAllIds();
        if (ids != null) {
            if (stream.writeByte(Codes.Host.OK)) {
                if (stream.writeInt(ids.length)) {
                    for (int idPos = 0; idPos < ids.length; idPos++) {
                        if (!stream.writeInt(ids[idPos])) {
                            return false;
                        }
                    }
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            stream.writeByte(Codes.Host.ERR);
            return true;
        }
    }

    private boolean host_geinf() {
        if (stream.writeByte(Codes.Host.OK)) {
            byte[] rid = stream.readInt();
            if (rid == null) {
                return false;
            }
            int id = ByteOperations.getInt(rid);
            String ICN = DBExecutor.getICN(id);
            int[] xPos = DBExecutor.getXPos(id);
            int[] yPos = DBExecutor.getYPos(id);
            int[] visitors = DBExecutor.getVisitors(id);
            int[] mark = DBExecutor.getMark(id);
            int[] time = DBExecutor.getTime(id);
            if (ICN == null || xPos == null || yPos == null || visitors == null || mark == null || time == null) {
                stream.writeByte(Codes.Host.ERR);
                return true;
            } else {
                if (stream.writeByte(Codes.Host.OK)) {
                    if (!stream.writeIntString(ByteOperations.getStringBytes(ICN))) return false;
                    if (!stream.writeInt(xPos[0])) return false;
                    if (!stream.writeInt(yPos[0])) return false;
                    if (!stream.writeInt(visitors[0])) return false;
                    if (!stream.writeInt(mark[0])) return false;
                    if (!stream.writeInt(time[0])) return false;
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }

    private boolean host_lin() {
        byte[] login = stream.readIntString();
        byte[] password = stream.readIntString();
        if (login == null || password == null) {
            return false;
        } else {
            if (ByteOperations.getString(login).equals(Server.login) && ByteOperations.getString(password).equals(Server.password)) {
                return stream.writeByte(Codes.Host.OK);
            } else {
                stream.writeByte(Codes.Host.ERR);
                return false;
            }
        }
    }

    private void host_oper() {
        boolean lined = false;
        while (stream.isWorking()) {
            if (stream.getAvailable() > 0) {
                byte[] command = stream.readByte();
                if (command != null) {
                    if (lined) {
                        switch (command[0]) {
                            case Codes.Host.PING -> {
                                if (!host_ping()) return;
                            }
                            case Codes.Host.DISC -> {
                                host_disconnect();
                                return;
                            }
                            case Codes.Host.GAEID -> {
                                if (!host_gaeid()) return;
                            }
                            case Codes.Host.GEINF -> {
                                if (!host_geinf()) return;
                            }
                        }
                    } else {
                        switch (command[0]) {
                            case Codes.Host.PING -> {
                                if (!host_ping()) return;
                            }
                            case Codes.Host.DISC -> {
                                host_disconnect();
                                return;
                            }
                            case Codes.Host.LIN -> {
                                if (host_lin()) lined = true;
                                else return;
                            }
                        }
                    }
                }
            }
        }
    }
}

