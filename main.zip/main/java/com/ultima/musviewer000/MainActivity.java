package com.ultima.musviewer000;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ultima.musviewer000.client.Client;

public class MainActivity extends AppCompatActivity {

    private static MainActivity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        Button cmplinbtn = findViewById(R.id.cntlinbtn);
        EditText linfld = findViewById(R.id.loginfld);
        EditText pasfld = findViewById(R.id.passwordfld);
        cmplinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String login = linfld.getText().toString();
                String password = pasfld.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if (Client.connect()) {
                            if (Client.handshake()) {
                                if (Client.lin(login, password)) {
                                    Client.startPinging();
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Intent intent = new Intent(MainActivity.this, MapActivity.class);
                                            startActivity(intent);
                                        }
                                    });
                                }
                            }
                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(context, "Failed to login\nrestart app", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }).start();
            }
        });
    }
}