package com.ultima.musviewer000.client;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

public class Client {

    private static final String ip = "172.20.10.2";
    private static final int port = 13039;

    private static Socket socket;
    private static APIStream stream;

    private static boolean sat = false;
    private static Timer pingsch;


    public static boolean connect() {
        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(ip, port));
            stream = new APIStream(socket.getInputStream(), socket.getOutputStream(), 30);
            return true;
        } catch (Exception unExc) {
            return false;
        }
    }

    public static boolean handshake() {
        if (stream.writeShort(Codes.Host.HANDSHAKE_CODE)) {
            byte[] resp = stream.readByte();
            if (resp != null) {
                return (resp[0] == Codes.Host.OK);
            }
        }
        return false;
    }

    public static boolean ping() {
        sat = true;
        if (stream.writeByte(Codes.Host.PING)) {
            byte[] resp = stream.readByte();
            if (resp != null) {
                sat = false;
                return (resp[0] == Codes.Host.OK);
            }
        }
        sat = false;
        return false;
    }

    public static boolean disconnect() {
        sat = true;
        boolean result = false;
        if (stream.writeByte(Codes.Host.DISC)) {
            byte[] resp = stream.readByte();
            if (resp != null) {
                if (resp[0] == Codes.Host.OK) {
                    result = true;
                }
            }
        }
        stream.close();
        try {socket.close();} catch (Exception unExc) {}
        sat = false;
        return result;
    }

    public static boolean lin(String login, String password) {
        sat = true;
        if (stream.writeByte(Codes.Host.LIN)) {
            if (stream.writeIntString(ByteOperations.getStringBytes(login))) {
                if (stream.writeIntString(ByteOperations.getStringBytes(password))) {
                    byte[] res = stream.readByte();
                    if (res != null) {
                        if (res[0] == Codes.Host.OK) {
                            sat = false;
                            return true;
                        }
                    }
                }
            }
        }
        sat = false;
        return false;
    }

    public static int[] gaeid() {
        sat = true;
        int[] result = null;
        if (stream.writeByte(Codes.Host.GAEID)) {
            byte[] resp = stream.readByte();
            if (resp != null) {
                if (resp[0] == Codes.Host.OK) {
                    byte[] cnt = stream.readInt();
                    if (cnt != null){
                        int[] tmp = new int[ByteOperations.getInt(cnt)];
                        for (int pos = 0; pos < tmp.length; pos++) {
                            byte[] val = stream.readInt();
                            if (val == null) {
                                sat = false;
                                return null;
                            }
                            tmp[pos] = ByteOperations.getInt(val);
                        }
                        result = tmp;
                    }
                }
            }
        }
        sat = false;
        return result;
    }

    public static class Einfo {
        int id;
        String ICN;
        int xPos;
        int yPos;
        int visitors;
        int mark;
        int time;

        public Einfo(int id, String ICN, int xPos, int yPos, int visitors, int mark, int time) {
            this.id = id;
            this.ICN = ICN;
            this.xPos = xPos;
            this.yPos = yPos;
            this.visitors = visitors;
            this.mark = mark;
            this.time = time;
        }
    }

    public static Einfo geinf(int id) {
        sat = true;
        Einfo result = null;
        if (stream.writeInt(id)) {
            byte[] rescd = stream.readByte();
            if (rescd != null) {
                if (rescd[0] == Codes.Host.OK) {
                    byte[] icn = stream.readIntString();
                    byte[] xPos = stream.readInt();
                    byte[] yPos = stream.readInt();
                    byte[] visitors = stream.readInt();
                    byte[] mark = stream.readInt();
                    byte[] time = stream.readInt();
                    if (icn != null && xPos != null && yPos != null && visitors != null && mark != null && time != null) {
                        result = new Einfo(
                                id,
                                ByteOperations.getString(icn),
                                ByteOperations.getInt(xPos),
                                ByteOperations.getInt(yPos),
                                ByteOperations.getInt(visitors),
                                ByteOperations.getInt(mark),
                                ByteOperations.getInt(time));
                    }
                }
            }
        }
        sat = false;
        return result;
    }

    public static void startPinging() {
        pingsch = new Timer();
        pingsch.schedule(new TimerTask() {
            @Override
            public void run() {
                if (!sat) ping();
            }
        }, 0, 5000);
    }

    public static void stopPinging() {
        pingsch.cancel();
    }

}
