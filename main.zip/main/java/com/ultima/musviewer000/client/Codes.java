package com.ultima.musviewer000.client;
public class Codes {

    public class Host {
        public static final short HANDSHAKE_CODE = 0x3239;

        public static final byte OK = 0x00;
        public static final byte ERR = 0x01;
        public static final byte PING = 0x02;
        public static final byte DISC = 0x03;

        public static final byte LIN = 0x08;

        public static final byte GAEID = 0x10; //Get all exhibits id's
        public static final byte GEINF = 0x11; //Get exhibit info

    }

    public class Camera {
        public static final short HANDSHAKE_CODE = 0x3339;

        public static final byte OK = 0x00;
        public static final byte ERR = 0x01;
        public static final byte PING = 0x02;
        public static final byte DISC = 0x03;

        public static final byte GEI = 0x10; //Get resent enterings
        public static final byte SEI = 0x11;
    }
}
