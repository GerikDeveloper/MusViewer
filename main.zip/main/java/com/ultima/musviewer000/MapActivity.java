package com.ultima.musviewer000;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MapActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_map);
        View view = findViewById(R.id.mapcanv);
        setContentView(view);
        Button updbtn = findViewById(R.id.updbtn);
        updbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
            }
        });
    }
}
