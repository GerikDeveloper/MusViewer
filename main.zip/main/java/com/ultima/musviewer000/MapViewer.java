package com.ultima.musviewer000;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.view.View;

public class MapViewer extends View {

    Bitmap bmp;
    public MapViewer(Context context) {
        super(context);
        bmp = BitmapFactory.decodeResource(getResources(), R.drawable.map);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawBitmap(bmp, 430, 900, null);
    }
}
