package org.example;

import java.net.Socket;

import static org.example.Server.log;

public class Devise {

    public static final int timeout = 30;
    private Socket socket;
    private APIStream stream;
    private short type = 0x0000;

    public Devise(Socket sock) {
        socket = sock;
        start();
    }

    private boolean handshake() {
        byte[] hshCode = stream.readShort();
        if (hshCode != null) {
            short code = ByteOperations.getShort(hshCode);
            if (code == Codes.Camera.HANDSHAKE_CODE) {
                if (stream.writeByte(Codes.Camera.OK)) {
                    type = code;
                    return true;
                } else {
                    return false;
                }
            } else if (code == Codes.Host.HANDSHAKE_CODE) {
                if (stream.writeByte(Codes.Host.OK)) {
                    type = code;
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private void start() {
        try {
            stream = new APIStream(socket.getInputStream(), socket.getOutputStream(), timeout);
        } catch (Exception unkExc) {
            log("Failed to open devise stream");
            return;
        }
        if (handshake()) {
            log("Devise successfully checked");
        } else {
            log("Failed to complete handshake");
            stream.close();
            return;
        }
        if (type == Codes.Camera.HANDSHAKE_CODE) {
            camera_oper();
            stream.close();
        } else if (type == Codes.Host.HANDSHAKE_CODE) {
            host_oper();
            stream.close();
        } else {
            log("Unknown code, devise will disconnect");
            stream.close();
            return;
        }
    }

    private boolean camera_gei() {
        byte[] id = stream.readInt();
        if (id == null) {
            return false;
        } else {
            int code = ByteOperations.getInt(id);
            String ICN = DBExecutor.getICN(code);
            int[] xPos = DBExecutor.getXPos(code);
            int[] yPos = DBExecutor.getYPos(code);
            int[] visitors = DBExecutor.getVisitors(code);
            int[] mark = DBExecutor.getMark(code);
            int[] time = DBExecutor.getTime(code);
            if (ICN == null || xPos == null || yPos == null || visitors == null || mark == null || time == null) {
                return stream.writeByte(Codes.Camera.ERR);
            } else {
                if (!stream.writeByte(Codes.Camera.OK)) return false;
                if (!stream.writeIntString(ByteOperations.getStringBytes(ICN))) return false;
                if (!stream.writeInt(xPos[0])) return false;
                if (!stream.writeInt(yPos[0])) return false;
                if (!stream.writeInt(visitors[0])) return false;
                if (!stream.writeInt(mark[0])) return false;
                if (!stream.writeInt(time[0])) return false;
                return true;
            }
        }
    }

    private boolean camera_sei() {
        byte[] id = stream.readInt();
        byte[] ICN = stream.readIntString();
        byte[] xPos = stream.readInt();
        byte[] yPos = stream.readInt();
        byte[] visitors = stream.readInt();
        byte[] mark = stream.readInt();
        byte[] time = stream.readInt();
        if (id == null || ICN == null || xPos == null || yPos == null || visitors == null || mark == null || time == null) {
            return false;
        } else {
            int code = ByteOperations.getInt(id);
            if (DBExecutor.setICN(code, ByteOperations.getString(ICN)) &&
                DBExecutor.setXPos(code, ByteOperations.getInt(xPos)) &&
                DBExecutor.setYPos(code, ByteOperations.getInt(yPos)) &&
                DBExecutor.setVisitors(code, ByteOperations.getInt(visitors)) &&
                DBExecutor.setMark(code, ByteOperations.getInt(mark)) &&
                DBExecutor.setTime(code, ByteOperations.getInt(time)))
            {
                return stream.writeByte(Codes.Camera.OK);
            } else {
                return stream.writeByte(Codes.Camera.ERR);
            }
        }
    }

    private boolean camera_ping() {
        return stream.writeByte(Codes.Camera.OK);
    }

    private void camera_disc() {
        stream.writeByte(Codes.Camera.DISC);
    }

    private void camera_oper() {
        while (stream.isWorking()) {
            if (stream.getAvailable() > 0) {
                byte[] command = stream.readByte();
                if (command != null) {
                    switch (command[0]) {
                        case Codes.Camera.PING -> {
                            if (!camera_ping()) return;
                        }
                        case Codes.Camera.DISC -> {
                            camera_disc();
                            return;
                        }
                        case Codes.Camera.GEI -> {
                            if (!camera_gei()) return;
                        }
                        case Codes.Camera.SEI -> {
                            if (!camera_sei()) return;
                        }
                    }
                }
            }
        }
    }

    private void host_disconnect() {
        stream.writeByte(Codes.Host.DISC);
    }

    private boolean host_ping() {
        return stream.writeByte(Codes.Host.OK);
    }

    private boolean host_gaeid() {
        int[] ids = DBExecutor.getAllIds();
        if (ids != null) {
            if (stream.writeByte(Codes.Host.OK)) {
                if (stream.writeInt(ids.length)) {
                    for (int idPos = 0; idPos < ids.length; idPos++) {
                        if (!stream.writeInt(ids[idPos])) {
                            return false;
                        }
                    }
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return stream.writeByte(Codes.Host.ERR);
        }
    }

    private boolean host_geinf() {
        if (stream.writeByte(Codes.Host.OK)) {
            byte[] rid = stream.readInt();
            if (rid == null) {
                return false;
            }
            int id = ByteOperations.getInt(rid);
            String ICN = DBExecutor.getICN(id);
            int[] xPos = DBExecutor.getXPos(id);
            int[] yPos = DBExecutor.getYPos(id);
            int[] visitors = DBExecutor.getVisitors(id);
            int[] mark = DBExecutor.getMark(id);
            int[] time = DBExecutor.getTime(id);
            if (ICN == null || xPos == null || yPos == null || visitors == null || mark == null || time == null) {
                return stream.writeByte(Codes.Host.ERR);
            } else {
                if (stream.writeByte(Codes.Host.OK)) {
                    if (!stream.writeIntString(ByteOperations.getStringBytes(ICN))) return false;
                    if (!stream.writeInt(xPos[0])) return false;
                    if (!stream.writeInt(yPos[0])) return false;
                    if (!stream.writeInt(visitors[0])) return false;
                    if (!stream.writeInt(mark[0])) return false;
                    if (!stream.writeInt(time[0])) return false;
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }

    private boolean host_lin() {
        byte[] login = stream.readIntString();
        byte[] password = stream.readIntString();
        if (login == null || password == null) {
            return false;
        } else {
            if (ByteOperations.getString(login).equals(Server.login) && ByteOperations.getString(password).equals(Server.password)) {
                return stream.writeByte(Codes.Host.OK);
            } else {
                stream.writeByte(Codes.Host.ERR);
                return false;
            }
        }
    }

    private void host_oper() {
        boolean lined = false;
        while (stream.isWorking()) {
            if (stream.getAvailable() > 0) {
                byte[] command = stream.readByte();
                if (command != null) {
                    if (lined) {
                        switch (command[0]) {
                            case Codes.Host.PING -> {
                                if (!host_ping()) return;
                            }
                            case Codes.Host.DISC -> {
                                host_disconnect();
                                return;
                            }
                            case Codes.Host.GAEID -> {
                                if (!host_gaeid()) return;
                            }
                            case Codes.Host.GEINF -> {
                                if (!host_geinf()) return;
                            }
                        }
                    } else {
                        switch (command[0]) {
                            case Codes.Host.PING -> {
                                if (!host_ping()) return;
                            }
                            case Codes.Host.DISC -> {
                                host_disconnect();
                                return;
                            }
                            case Codes.Host.LIN -> {
                                if (host_lin()) {
                                    lined = true;
                                    log("Host devise logged in");
                                } else {
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

