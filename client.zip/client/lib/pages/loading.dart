import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class LoadingPage extends StatefulWidget {
  const LoadingPage({super.key, required this.title});
  
  final String title;

  @override
  State<LoadingPage> createState() => LoadingPageState();
}

class LoadingPageState extends State<LoadingPage> {

  final TextEditingController loginCtr = TextEditingController();
  final TextEditingController passwordCtr = TextEditingController();

  @override
  void dispose() {
    loginCtr.dispose();
    passwordCtr.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Scaffold(
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              alignment: Alignment.bottomCenter,
              padding: const EdgeInsets.all(10),
              child: 
              SvgPicture.asset(
                'assets/images/logo.svg',
              ),
            ),
            Container(
              alignment: Alignment.bottomCenter,
              padding: const EdgeInsets.all(10),
              child:
              Text(
                'MusViewer',
                style: TextStyle(
                  fontFamily: 'Mono',
                  fontSize: 33.0 * fem,
                  color: Colors.black54,
                ),
              ),
            ),
            Container(
              alignment: Alignment.bottomCenter,
              padding: const EdgeInsets.all(10),
              child:
              TextField(
              controller: loginCtr,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Login',
              ),
            ),
            ),
            Container(
              alignment: Alignment.bottomCenter,
              padding: const EdgeInsets.all(10),
              child:
              TextField(
              controller: passwordCtr,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Password',
              ),
            ),
            ),
            Container(
              alignment: Alignment.bottomCenter,
              padding: const EdgeInsets.all(10),
              child:
              TextButton(
                onPressed: (){
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        content: Text(loginCtr.text + ' ' + passwordCtr.text),
                      );
                    },
                  );
                },
                child: const Text('Enter'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}