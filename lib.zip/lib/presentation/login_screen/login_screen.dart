import 'package:app002/core/app_export.dart';
import 'package:app002/widgets/custom_elevated_button.dart';
import 'package:app002/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController edittextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 27.h,
            top: 129.v,
            right: 27.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              CustomImageView(
                svgPath: ImageConstant.imgGroup9,
                height: 157.v,
                width: 134.h,
                alignment: Alignment.center,
              ),
              SizedBox(height: 25.v),
              Align(
                alignment: Alignment.center,
                child: SizedBox(
                  height: 37.v,
                  width: 156.h,
                  child: Stack(
                    alignment: Alignment.topLeft,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Text(
                          "MusViewer",
                          style: theme.textTheme.headlineLarge,
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgGroup6,
                        height: 29.adaptSize,
                        width: 29.adaptSize,
                        alignment: Alignment.topLeft,
                        margin: EdgeInsets.only(top: 2.v),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(
                    left: 9.h,
                    top: 35.v,
                  ),
                  child: Text(
                    "Login",
                    style: CustomTextStyles.headlineLargeSecondaryContainer,
                  ),
                ),
              ),
              CustomTextFormField(
                controller: edittextController,
                margin: EdgeInsets.only(
                  left: 20.h,
                  top: 7.v,
                ),
                textInputAction: TextInputAction.done,
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(
                    left: 8.h,
                    top: 22.v,
                  ),
                  child: Text(
                    "Password",
                    style: CustomTextStyles.headlineLargeSecondaryContainer,
                  ),
                ),
              ),
              SizedBox(height: 10.v),
              Container(
                height: 50.v,
                width: 356.h,
                decoration: BoxDecoration(
                  color: appTheme.gray600,
                  borderRadius: BorderRadius.circular(
                    20.h,
                  ),
                ),
              ),
              CustomElevatedButton(
                width: 220.h,
                text: "Enter",
                margin: EdgeInsets.only(
                  top: 37.v,
                  right: 68.h,
                  bottom: 5.v,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
