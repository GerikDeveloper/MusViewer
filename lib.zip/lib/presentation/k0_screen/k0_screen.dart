import 'package:app002/core/app_export.dart';
import 'package:flutter/material.dart';

class K0Screen extends StatelessWidget {
  const K0Screen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(
                height: 24.v,
                width: double.maxFinite,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        height: 24.v,
                        width: double.maxFinite,
                        decoration: BoxDecoration(
                          color: theme.colorScheme.primaryContainer,
                        ),
                      ),
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgRectangle,
                      height: 24.v,
                      width: 423.h,
                      alignment: Alignment.center,
                    ),
                  ],
                ),
              ),
              Spacer(),
              SizedBox(
                height: 155.v,
                width: 137.h,
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        margin: EdgeInsets.only(left: 3.h),
                        decoration:
                            AppDecoration.fillOnPrimaryContainer.copyWith(
                          borderRadius: BorderRadiusStyle.circleBorder67,
                        ),
                        child: Container(
                          height: 134.adaptSize,
                          width: 134.adaptSize,
                          decoration: BoxDecoration(
                            color: theme.colorScheme.onPrimaryContainer,
                            borderRadius: BorderRadius.circular(
                              67.h,
                            ),
                          ),
                        ),
                      ),
                    ),
                    CustomImageView(
                      svgPath: ImageConstant.imgLogoproto7,
                      height: 132.v,
                      width: 133.h,
                      alignment: Alignment.topCenter,
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        height: 134.adaptSize,
                        width: 134.adaptSize,
                        decoration: BoxDecoration(
                          color: theme.colorScheme.onPrimaryContainer,
                          borderRadius: BorderRadius.circular(
                            67.h,
                          ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        height: 134.adaptSize,
                        width: 134.adaptSize,
                        decoration: BoxDecoration(
                          color: theme.colorScheme.onPrimaryContainer,
                          borderRadius: BorderRadius.circular(
                            67.h,
                          ),
                        ),
                      ),
                    ),
                    CustomImageView(
                      svgPath: ImageConstant.imgLogoproto8,
                      height: 132.v,
                      width: 133.h,
                      alignment: Alignment.topCenter,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 12.v),
              SizedBox(
                height: 37.v,
                width: 156.h,
                child: Stack(
                  alignment: Alignment.topLeft,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Text(
                        "MusViewer",
                        style: theme.textTheme.headlineLarge,
                      ),
                    ),
                    CustomImageView(
                      svgPath: ImageConstant.imgHome,
                      height: 30.v,
                      width: 29.h,
                      alignment: Alignment.topLeft,
                      margin: EdgeInsets.only(top: 2.v),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 12.v),
            ],
          ),
        ),
      ),
    );
  }
}
