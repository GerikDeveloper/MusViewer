import 'package:app002/core/app_export.dart';
import 'package:app002/widgets/app_bar/appbar_image.dart';
import 'package:app002/widgets/app_bar/appbar_image_1.dart';
import 'package:app002/widgets/app_bar/appbar_title.dart';
import 'package:app002/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

class K3Screen extends StatelessWidget {
  const K3Screen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        appBar: CustomAppBar(
          leadingWidth: double.maxFinite,
          leading: AppbarImage1(
            svgPath: ImageConstant.imgHomeOnprimarycontainer,
            margin: EdgeInsets.only(
              left: 14.h,
              right: 341.h,
              bottom: 12.v,
            ),
          ),
          title: Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Row(
              children: [
                Container(
                  height: 75.adaptSize,
                  width: 75.adaptSize,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.onPrimaryContainer,
                    borderRadius: BorderRadius.circular(
                      37.h,
                    ),
                  ),
                ),
                Container(
                  height: 36.999996.v,
                  width: 160.h,
                  margin: EdgeInsets.only(
                    left: 5.h,
                    top: 17.v,
                    bottom: 20.v,
                  ),
                  child: Stack(
                    alignment: Alignment.topLeft,
                    children: [
                      AppbarTitle(
                        text: "MusViewer",
                      ),
                      AppbarImage(
                        svgPath: ImageConstant.imgHome,
                        margin: EdgeInsets.fromLTRB(2.h, 2.v, 129.h, 4.v),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        body: Container(
          width: 349.h,
          margin: EdgeInsets.fromLTRB(40.h, 13.v, 40.h, 5.v),
          padding: EdgeInsets.symmetric(
            horizontal: 45.h,
            vertical: 40.v,
          ),
          decoration: AppDecoration.fillOnPrimaryContainer.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder36,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 3.v),
              Card(
                clipBehavior: Clip.antiAlias,
                elevation: 0,
                color: appTheme.gray700,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadiusStyle.roundedBorder20,
                ),
                child: Container(
                  height: 616.v,
                  width: 257.h,
                  decoration: AppDecoration.fillGray.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder20,
                  ),
                  child: Stack(
                    alignment: Alignment.topCenter,
                    children: [
                      CustomImageView(
                        svgPath: ImageConstant.imgLine11,
                        height: 1.v,
                        width: 43.h,
                        alignment: Alignment.centerRight,
                        margin: EdgeInsets.only(right: 86.h),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: SizedBox(
                          height: 529.v,
                          child: VerticalDivider(
                            width: 1.h,
                            thickness: 1.v,
                            indent: 36.h,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: SizedBox(
                          height: 47.v,
                          child: VerticalDivider(
                            width: 1.h,
                            thickness: 1.v,
                            endIndent: 2.h,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          margin: EdgeInsets.only(left: 1.h),
                          padding: EdgeInsets.symmetric(
                            horizontal: 7.h,
                            vertical: 12.v,
                          ),
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: fs.Svg(
                                ImageConstant.imgGroup8,
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 5.h),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 54.v),
                              Text(
                                "Выставка",
                                style: theme.textTheme.headlineMedium,
                              ),
                              Align(
                                alignment: Alignment.centerRight,
                                child: Container(
                                  height: 22.adaptSize,
                                  width: 22.adaptSize,
                                  margin: EdgeInsets.only(
                                    top: 2.v,
                                    right: 5.h,
                                  ),
                                  decoration: BoxDecoration(
                                    color: appTheme.gray500,
                                    borderRadius: BorderRadius.circular(
                                      11.h,
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    left: 5.h,
                                    top: 4.v,
                                    right: 11.h,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Container(
                                        height: 22.adaptSize,
                                        width: 22.adaptSize,
                                        margin: EdgeInsets.only(top: 16.v),
                                        decoration: BoxDecoration(
                                          color: appTheme.gray500,
                                          borderRadius: BorderRadius.circular(
                                            11.h,
                                          ),
                                        ),
                                      ),
                                      Spacer(),
                                      Container(
                                        height: 22.adaptSize,
                                        width: 22.adaptSize,
                                        margin: EdgeInsets.only(top: 16.v),
                                        decoration: BoxDecoration(
                                          color: appTheme.gray500,
                                          borderRadius: BorderRadius.circular(
                                            11.h,
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(
                                          left: 27.h,
                                          bottom: 9.v,
                                        ),
                                        child: Text(
                                          "Галерея",
                                          style: theme.textTheme.headlineMedium,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: 5.h,
                                  top: 43.v,
                                  right: 5.h,
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      margin: EdgeInsets.only(top: 14.v),
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                    Spacer(
                                      flex: 36,
                                    ),
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      margin: EdgeInsets.only(top: 14.v),
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                    Spacer(
                                      flex: 63,
                                    ),
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      margin: EdgeInsets.only(bottom: 14.v),
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: 5.h,
                                  top: 11.v,
                                  right: 21.h,
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      margin: EdgeInsets.only(top: 29.v),
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      margin: EdgeInsets.only(top: 29.v),
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                        left: 20.h,
                                        bottom: 15.v,
                                      ),
                                      child: Text(
                                        "Кассы",
                                        style: CustomTextStyles
                                            .headlineLargeBlack900,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: 15.h,
                                  top: 14.v,
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 19.v),
                                      child: Text(
                                        "Холл 2",
                                        style: theme.textTheme.headlineMedium,
                                      ),
                                    ),
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      margin: EdgeInsets.only(
                                        left: 36.h,
                                        top: 26.v,
                                      ),
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 5.h),
                                child: Row(
                                  children: [
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      margin: EdgeInsets.only(left: 60.h),
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Align(
                                alignment: Alignment.centerRight,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    top: 20.v,
                                    right: 5.h,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        height: 22.adaptSize,
                                        width: 22.adaptSize,
                                        margin: EdgeInsets.only(
                                          top: 20.v,
                                          bottom: 35.v,
                                        ),
                                        decoration: BoxDecoration(
                                          color: appTheme.gray500,
                                          borderRadius: BorderRadius.circular(
                                            11.h,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        width: 82.h,
                                        margin: EdgeInsets.only(left: 17.h),
                                        child: Text(
                                          "Экспозиция",
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.center,
                                          style: theme.textTheme.headlineMedium!
                                              .copyWith(
                                            height: 1.50,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        height: 22.adaptSize,
                                        width: 22.adaptSize,
                                        margin: EdgeInsets.only(
                                          left: 5.h,
                                          top: 20.v,
                                          bottom: 35.v,
                                        ),
                                        decoration: BoxDecoration(
                                          color: appTheme.gray500,
                                          borderRadius: BorderRadius.circular(
                                            11.h,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: 16.h,
                                  top: 1.v,
                                ),
                                child: Text(
                                  "Холл 1",
                                  style: theme.textTheme.headlineMedium,
                                ),
                              ),
                              Align(
                                alignment: Alignment.centerRight,
                                child: Container(
                                  height: 22.adaptSize,
                                  width: 22.adaptSize,
                                  margin: EdgeInsets.only(
                                    top: 4.v,
                                    right: 5.h,
                                  ),
                                  decoration: BoxDecoration(
                                    color: appTheme.gray500,
                                    borderRadius: BorderRadius.circular(
                                      11.h,
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: 5.h,
                                  top: 12.v,
                                  right: 46.h,
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: 22.adaptSize,
                                      width: 22.adaptSize,
                                      decoration: BoxDecoration(
                                        color: appTheme.gray500,
                                        borderRadius: BorderRadius.circular(
                                          11.h,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
