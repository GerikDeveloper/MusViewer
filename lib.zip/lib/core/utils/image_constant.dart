class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Лоадинг - директор images
  static String imgRectangle = '$imagePath/img_rectangle.png';

  static String imgLogoproto7 = '$imagePath/img_logoproto7.svg';

  static String imgLogoproto8 = '$imagePath/img_logoproto8.svg';

  // Login - директор images
  static String imgGroup9 = '$imagePath/img_group9.svg';

  static String imgGroup6 = '$imagePath/img_group6.svg';

  // Интерактивная карта - директор images
  static String imgBookmark = '$imagePath/img_bookmark.svg';

  static String imgHomeGray600 = '$imagePath/img_home_gray_600.svg';

  static String imgGraph = '$imagePath/img_graph.svg';

  static String imgPin = '$imagePath/img_pin.svg';

  // Common images
  static String imgHome = '$imagePath/img_home.svg';

  static String imgHomeOnprimarycontainer =
      '$imagePath/img_home_onprimarycontainer.svg';

  static String imgLine11 = '$imagePath/img_line11.svg';

  static String imgGroup8 = '$imagePath/img_group8.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
