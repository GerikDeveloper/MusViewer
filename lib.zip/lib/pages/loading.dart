import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class LoadingPage extends StatefulWidget {
  const LoadingPage({super.key, required this.title});
  
  final String title;

  @override
  State<LoadingPage> createState() => LoadingPageState();
}

class LoadingPageState extends State<LoadingPage> {

  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Scaffold(
      body: TextButton(
        // ViF (9:24)
        onPressed:  () {},
        style:  TextButton.styleFrom (
          padding:  EdgeInsets.zero,
        ),
        child:  Container(
          width:  double.infinity,
          decoration:  const BoxDecoration (
            color:  Color(0xff403d3d),
          ),
          child:  Column(
            crossAxisAlignment:  CrossAxisAlignment.end,
            children:  [
              Container(
                margin:  EdgeInsets.fromLTRB(2.5 * fem, 0 * fem, 0 * fem, 6 * fem),
                width:  136 * fem,
                height:  134 * fem,
                child:  
                  SvgPicture.asset(
                    'assets/images/logogo.svg',
                    width:  136 * fem,
                    height:  134 * fem,
                    color: const Color.fromARGB(0xff, 0xd0, 0xd0, 0xd0),
                    
                  ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}