import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Headline text style
  static get headlineLargeBlack900 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.black900.withOpacity(0.4),
        fontSize: 32.fSize,
      );
  static get headlineLargeBlack900_1 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.black900,
      );
  static get headlineLargeGray500 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.gray500,
      );
  static get headlineLargeGray600 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.gray600,
      );
  static get headlineLargeGray600Regular =>
      theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.gray600,
        fontWeight: FontWeight.w400,
      );
  static get headlineLargeSecondaryContainer =>
      theme.textTheme.headlineLarge!.copyWith(
        color: theme.colorScheme.secondaryContainer,
        fontWeight: FontWeight.w400,
      );
}

extension on TextStyle {
  TextStyle get podkova {
    return copyWith(
      fontFamily: 'Podkova',
    );
  }
}
