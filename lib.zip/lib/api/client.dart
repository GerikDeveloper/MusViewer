import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'codes.dart';

class Client {

  static late Socket socket;

  static Future<bool> connect(String ip, int port) async {
    try {
      socket = await Socket.connect(ip, port).timeout(const Duration(seconds: 5));
      return true;
    } catch (unkExc) {
      return false;
    }
  }

  static Future<bool> handshake() async {
    try {
      socket.add(Codes.handshakeCode);
      bool result = false;
      socket.listen((List<int> data) {
        if (data[0] == Codes.ok[0]) {
          result = true;
        }
      });
      return result;
    } catch (unExc){
      try {socket.close();} catch(unExc) {};
      return false;
    }
  }

  static bool ping() {
    try {
      socket.add(Codes.ping);
      bool result = false;
      socket.listen((List<int> data) {
        if (data[0] == Codes.ok[0]) {
          result = true;
        }
      });
      return result;
    } catch (unExc){
      try {socket.close();} catch(unExc) {};
      return false;
    }
  }

  static bool disconnect() {
    try {
      socket.add(Codes.disc);
      bool result = false;
      socket.listen((List<int> data) {
        if (data[0] == Codes.ok[0]) {
          result = true;
        }
      });
      socket.close();
      return result;
    } catch (unkExc) {
      try {socket.close();} catch(unExc) {};
      return false;
    }
  }

  static bool lin(String login, String password) {
    try {
      var blenLog = ByteData(4)..setUint32(0, login.length);
      var blenPas = ByteData(4)..setUint32(0, password.length);
      socket.add(blenLog.buffer.asUint8List());
      socket.add(utf8.encode(login));
      socket.add(blenPas.buffer.asUint8List());
      socket.add(utf8.encode(password));
      bool result = false;
      socket.listen((List<int> data) {
        if (data[0] == Codes.ok[0]) {
          result = true;
        }
      });
      if (!result) {
        try {socket.close();} catch(unExc) {};
      }
      return result;
    } catch (unkExc) {
      try {socket.close();} catch(unExc) {};
      return false;
    }
  }

/*  static List<int> gaeid() {
    try {
      StreamConsumer<Uint8> ;
      socket.pipe();
    } catch (unExc) {
      try {socket.close();} catch(unExc) {};
      return List.filled(0, 0x00);
    }
  }
 */
}