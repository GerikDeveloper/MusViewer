class Codes {
  static const List<int> handshakeCode = [0x39, 0x32];

  static const List<int> ok = [0x00];
  static const List<int> err = [0x01];
  static const List<int> ping = [0x02];
  static const List<int> disc = [0x03];

  static const List<int> lin = [0x08];

  static const List<int> gaeid = [0x10];
  static const List<int> geinf = [0x11];
}