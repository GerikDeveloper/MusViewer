import 'package:flutter/material.dart';
import 'package:clientmus000/presentation/k0_screen/k0_screen.dart';
import 'package:clientmus000/presentation/login_screen/login_screen.dart';
import 'package:clientmus000/presentation/k2_screen/k2_screen.dart';
import 'package:clientmus000/presentation/k3_screen/k3_screen.dart';
import 'package:clientmus000/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String k0Screen = '/k0_screen';

  static const String loginScreen = '/login_screen';

  static const String k2Screen = '/k2_screen';

  static const String k3Screen = '/k3_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    k0Screen: (context) => K0Screen(),
    loginScreen: (context) => LoginScreen(),
    k2Screen: (context) => K2Screen(),
    k3Screen: (context) => K3Screen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
